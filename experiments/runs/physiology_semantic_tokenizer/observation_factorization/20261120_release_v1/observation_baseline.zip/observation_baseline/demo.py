"""Portable inference smoke test. Only synthetic inputs; no data/cache setup or training."""
from pathlib import Path
import json
import numpy as np
from src.tokenizers.observation_baseline import ObservationBaseline
root=Path(__file__).resolve().parent
baseline=ObservationBaseline(root)
rng=np.random.default_rng(2207); stats={}
for modality, channels, ticks in [('eeg',1,400),('hb',2,20)]:
    x=rng.normal(size=(7,channels,ticks)).astype('float32') # complete 2 s, already in training coordinates
    ids=baseline.encode(x,modality) # one nominal 0..15 per patch
    code=baseline.encode(x,modality,detail=True)
    np.testing.assert_array_equal(ids['pattern'],code['pattern'])
    record={}
    for detail,values in [(False,ids),(True,code)]:
        wire=baseline.pack(values,modality,detail=detail)
        mode='full' if detail else 'ids'; bits=baseline.manifest['modalities'][modality]['total_bits_per_patch'] if detail else 4
        assert len(wire)==(len(x)*bits+7)//8
        recv=baseline.unpack(wire,len(x),modality,detail=detail)
        y=baseline.decode(recv,modality,detail=detail)
        np.testing.assert_array_equal(y,baseline.decode(values,modality,detail=detail))
        assert y.shape==x.shape and np.isfinite(y).all()
        record[mode]={'bits_per_item':bits,'batch_bytes':len(wire)}
    stats[modality]=dict(**record,n_items=len(x))
print(json.dumps({'status':'passed','synthetic_only':True,'payload':stats},indent=2))
