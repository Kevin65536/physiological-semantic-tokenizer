# 两秒双流观测 tokenizer｜开发版

用途：先保留可解释的观测词，然后让波形消费者按需要读取细节。**这是四库公开开发面板上的工程基线，并非独立确认、生理状态标签、临床模型或 S/O 分离器。** 心算验证没有显示对盲波形词的优势。模型及推断代码随附，可在不恢复研究数据库的情况下运行。

```bash
# 在解压后的 observation_baseline 目录；使用已有仓库环境或按 requirements.txt 配置兼容 Python
python demo.py
```

```python
from pathlib import Path
from src.tokenizers.observation_baseline import ObservationBaseline
b = ObservationBaseline(Path('.'))
# x: 完整、已过 G0 预处理且已除训练位点尺度的 numpy 数组，见下文
ids = b.encode(x, 'eeg')['pattern']                 # 与 full 的 pattern 逐项相同，下游可只读该列
code = b.encode(x, 'eeg', detail=True)             # 只含整数，无实时浮点数送入 decoder
wire = b.pack(code, 'eeg', detail=True)
y = b.decode(b.unpack(wire, len(x), 'eeg', detail=True), 'eeg', detail=True)
```

|输入|词流|完整波形负载/2秒/原生位置|开发整体工程线|
|---|---|---:|---|
|EEG：`[N,1,400]`，200 Hz，一电极|4 bit：相对频谱|512 bit：含ID、8-bit均值、6-bit增益及整数形状|达到|
|Hb：`[N,2,20]`，10 Hz；同一位置依次 HbO、HbR|4 bit：两色水平与斜率|32 bit：含ID与逐词分配的整数细节|达到|

**坐标与边界**：不用原始电压/光强直接调用。使用指定 G0 预处理（含既有离线滤波、Hb 校准）；若只有未除尺度的 *G0 X*，先 `x=b.scale_g0(g0_x,'eeg',dataset,position)`，它只除以已有训练尺度，不减片内均值，不增加验证校准。Hb 两色共用输入尺度但评估方差分色。无效或不完整片保留 mask，不能补零生成假词。在 G0 以外的设备/人群，不能默认此坐标、码分布或阈值适用。

**下游模块**：传 `(dataset, subject, record, modality, position, native_time, valid, ID)`；ID 是类别，不是有序数，EEG 和 Hb 同号不对应。`pattern_atlas.csv` 是每个固定 ID 在训练与验证中真实属性的四分位数与支持量；罕见/零支持 ID 不做状态命名。`detail=False` 解码只给训练原型，不能用它恢复 EEG 相位。完整码率包括每片所有测量信息；版本/位置/时钟/计数/有效性和固定字典为双方预先共享，仅整批末字节补零。

**验证与安全**：`manifest.json` 记录库版本、模型校验和、运行及坐标身份。`demo.py` 只生成合成输入，核对 ID 一致、真实字节数和解码回放。joblib 只能从可信的本地发布者加载；清单校验和不是签名。用于研究而非诊疗。
